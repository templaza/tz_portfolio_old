
DROP TABLE IF EXISTS `#__tz_portfolio_vote`